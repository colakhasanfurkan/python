This project is published under the Creative Commons Zero (CC0) license. 

You can use the code for any project you like, including commercial ones. Attributions would be appreciated but are not required. 

The art assets and the soundtrack have been done by Pixel-boy and AAA and can be found here: https://pixel-boy.itch.io/ninja-adventure-asset-pack
They are also published under a CC0 license. 
